<?php


namespace Drupal\form_validate\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;

class test extends FormBase {

  public static $count_table;

  public $year;

  public function getFormId() {
    return 'form_validation';
  }

  public function buildForm(array $form, FormStateInterface $form_state) {
    $form['submit'] = array(
      '#type' => 'submit',
      '#value' => t('Submit'),
    );

    // table
    $form['myTable'] = array(
      '#type' => 'table',
      '#header' => array(t('COL 1'), t('COL 2'), t('COL 3')),
      '#prefix' => '<div id="my-table-wrapper">',
      '#suffix' => '</div>',
    );
    // Build the table rows and columns.
    for ($cpt = 0; $cpt <= 0; $cpt++) {
      // Table row
      $form['myTable'][$cpt] = $this->getTableLine($cpt);
    }


    // Build the extra lines
    $triggeringElement = $form_state->getTriggeringElement();
    $clickCounter = 0;
    // if a click occurs
    if ($triggeringElement and $triggeringElement['#attributes']['id'] == 'add-row') {
      // click counter is incremented
      // $formstate and $form element are updated
      $clickCounter=$form_state->getValue('click_counter');
      $clickCounter++;
      $form_state->setValue('click_counter',$clickCounter);
      $form['click_counter'] = array('#type' => 'hidden', '#default_value' => 0, '#value' => $clickCounter);
    } else {
      $form['click_counter'] = array('#type' => 'hidden', '#default_value' => 0);
    }

    // Build the extra table rows and columns.
    for ($k=0 ; $k<$clickCounter ; $k++) {
      $form['myTable'][$k] = $this->getTableLine($k);
    }


    $form['addRow'] = array(
      '#type' => 'button',
      '#value' => t('Add a row'),
      '#ajax' => array(
        'callback' =>  '::ajaxAddRow',
        'event' => 'click',
        'wrapper' => 'my-table-wrapper',
      ),
      '#attributes' => array(
        'id' =>  'add-row'
      ),
    );

    return $form;
  }

  function getTableLine($key) {
    $year = 2019;
    $mounth['year'] = 'Year';
    for ($i = 1; $i <= 12; $i++) {
      $mounth[$i] = date('F', mktime(1, 0, 0, $i, 5));
      if ($i % 3 == 0) {
        $mounth['q' . $i] = 'Q' . $i / 3;
      }
    }
    foreach ($mounth as $key => $value) {
      $default_value = isset($_POST['mounth'])?'':$_POST['mounth'][$i][$key];
      if ($key == 'year') {
        $form['mounth'][$i][$key] = [
          '#type'     => 'textfield',
          '#size'     => '4',
          '#value'    => $year,
          '#disabled' => TRUE,
        ];
      }
      elseif (substr($key, 0, 1) == 'q') {
        $form['mounth'][$i][$key] = [
          '#type'     => 'number',
          '#size'     => '4',
          '#min'      => 0,
          '#id'       => $key.$i,
          '#disabled' => 'disabled',
          '#default_value' => $default_value,
          '#ajax'     => [
            'callback' => '::YearAjaxCallback',
            'event'    => 'change',
            'wrapper'  => 'year_value',
          ],
        ];
      }
      elseif ($key == 'ytd') {
        $form['mounth'][$i][$key] = [
          '#type'     => 'number',
          '#size'     => '4',
          '#min'      => 0,
          '#disabled' => TRUE,
          '#id'       => 'year_value',
          '#default_value' => $default_value,
          '#prefix'   => '<div id="edit-outut">',
          '#suffix'   => '</div>',
        ];
      }
      else {
        $form['mounth'][$i][$key] = [
          '#type'  => 'number',
          '#min'   => 0,
          '#width' => 4,
          '#default_value' => $default_value,
          '#ajax'  => [
            'callback'        => '::myAjaxCallback',
            'disable-refocus' => FALSE,
            'event'           => 'change',
            'wrapper'         => 'qq3',
          ],
        ];
      }
    }
    $form['mounth']['actions']['newrow'] = [
      '#type'        => 'submit',
      '#value'       => $this->t('New row'),
      '#submit' => array('::ajaxAddRow'),
    ];
    return $form;
  }

  function ajaxAddRow($form, $form_state) {
    $cpt=0;
    for ($x = 0;; $x++) {
      $cpt++;
    }

    // $cpt always return 6 - expected to increment
    // $form['myTable'][$cpt] is always empty

    $form['myTable'][$cpt] = $this->getTableLine($cpt);

    return $form['myTable'];

  }

  public function submitForm(array &$form, FormStateInterface $form_state) {

  }

}