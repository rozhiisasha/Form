<?php


namespace Drupal\form_validate\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;

class fotmtest extends FormBase {

  public static $count_table;

  public $year;

  public function getFormId() {
    return 'form_validation';
  }

  public function buildForm(array $form, FormStateInterface $form_state) {
    $form['submit'] = array(
      '#type' => 'submit',
      '#value' => t('Submit'),
    );

    // table
    $form['myTable'] = array(
      '#type' => 'table',
      '#header' => array(t('COL 1'), t('COL 2'), t('COL 3')),
      '#prefix' => '<div id="my-table-wrapper">',
      '#suffix' => '</div>',
    );
    // Build the table rows and columns.
    for ($cpt = 0; $cpt <= 0; $cpt++) {
      // Table row
      $form['myTable'][$cpt] = $this->getTableLine($cpt);
    }


    // Build the extra lines
    $triggeringElement = $form_state->getTriggeringElement();
    $clickCounter = 0;
    // if a click occurs
    if ($triggeringElement and $triggeringElement['#attributes']['id'] == 'add-row') {
      // click counter is incremented
      // $formstate and $form element are updated
      $clickCounter=$form_state->getValue('click_counter');
      $clickCounter++;
      $form_state->setValue('click_counter',$clickCounter);
      $form['click_counter'] = array('#type' => 'hidden', '#default_value' => 0, '#value' => $clickCounter);
    } else {
      $form['click_counter'] = array('#type' => 'hidden', '#default_value' => 0);
    }

    // Build the extra table rows and columns.
    for ($k=0 ; $k<$clickCounter ; $k++) {
      $form['myTable'][$k] = $this->getTableLine($k);
    }


    $form['addRow'] = array(
      '#type' => 'button',
      '#value' => t('Add a row'),
      '#ajax' => array(
        'callback' =>  '::ajaxAddRow',
        'event' => 'click',
        'wrapper' => 'my-table-wrapper',
      ),
      '#attributes' => array(
        'id' =>  'add-row'
      ),
    );

    return $form;
  }

  function getTableLine($key) {
    $line = array();

    $line['col_1'] = array(
      '#type' => 'textfield',
      '#default_value' => 'col 1 - row ' . $key,
    );
    $line['col_2'] = array(
      '#type' => 'textfield',
      '#default_value' => 'col 2 - row ' . $key,
    );
    $line['col_3'] = array(
      '#type' => 'textfield',
      '#default_value' => 'col 3 - row ' . $key,
    );
    return $line;
  }

  function ajaxAddRow($form, $form_state) {
    $cpt=0;
    for ($x = 0;; $x++) {
      $cpt++;
    }

    // $cpt always return 6 - expected to increment
    // $form['myTable'][$cpt] is always empty

    $form['myTable'][$cpt] = $this->getTableLine($cpt);

    return $form['myTable'];

  }

  public function submitForm(array &$form, FormStateInterface $form_state) {

  }

}